# Code analysis
## kopintdatorg 
#### Version 1.0 

**By: Administrator**

*Date: 2021-07-19*

## Introduction
This document contains results of the code analysis of kopintdatorg



## Configuration

- Quality Profiles
    - Names: Sonar way [Java]; 
    - Files: AXqxosWDZoEgNxc52Dau.json; 
 - Quality Gate
    - Name: Sonar way
    - File: Sonar way.xml

## Synthesis
Quality Gate | Reliability | Security | Maintainability | Coverage | Duplications
:---:|:---:|:---:|:---:|:---:|:---:
OK | A | A | A | 0.0 % | 0.0 %

## Metrics

\ | Cyclomatic Complexity | Cognitive Complexity | Lines of code per file | Coverage | Comment density (%) | Duplication (%)
:---|:---:|:---:|:---:|:---:|:---:|:---:
Min | 4.0 | 0.0 | 24.0 | 0.0 | 9.1 | 0.0
Max | 22.0 | 2.0 | 154.0 | 0.0 | 22.6 | 0.0

## Volume

Language|Number
---|---
Java|154
Total|154


## Issues count by severity and types

Type|Severity|Number
---|---|---
VULNERABILITY|BLOCKER|0
VULNERABILITY|CRITICAL|0
VULNERABILITY|MAJOR|0
VULNERABILITY|MINOR|0
VULNERABILITY|INFO|0
BUG|BLOCKER|0
BUG|CRITICAL|0
BUG|MAJOR|0
BUG|MINOR|0
BUG|INFO|0
CODE_SMELL|BLOCKER|0
CODE_SMELL|CRITICAL|0
CODE_SMELL|MAJOR|1
CODE_SMELL|MINOR|2
CODE_SMELL|INFO|0
SECURITY_HOTSPOT|BLOCKER|0
SECURITY_HOTSPOT|CRITICAL|0
SECURITY_HOTSPOT|MAJOR|0
SECURITY_HOTSPOT|MINOR|0
SECURITY_HOTSPOT|INFO|0


## Issues
Name|Description|Type|Severity|Number
---|---|---|---|---
Standard outputs should not be used directly to log anything|When logging a message there are several important requirements which must be fulfilled: <br />  <br />    The user must be able to easily retrieve the logs  <br />    The format of all logged message must be uniform to allow the user to easily read the log  <br />    Logged data must actually be recorded  <br />    Sensitive data must only be logged securely  <br />  <br /> If a program directly writes to the standard outputs, there is absolutely no way to comply with those requirements. That's why defining and using a <br /> dedicated logger is highly recommended. <br /> Noncompliant Code Example <br />  <br /> System.out.println("My Message");  // Noncompliant <br />  <br /> Compliant Solution <br />  <br /> logger.log("My Message"); <br />  <br /> See <br />  <br />    CERT, ERR02-J. - Prevent exceptions while logging data  <br /> |CODE_SMELL|MAJOR|1
Public constants and fields initialized at declaration should be "static final" rather than merely "final"|Making a public constant just final as opposed to static final leads to duplicating its value for every <br /> instance of the class, uselessly increasing the amount of memory required to execute the application. <br /> Further, when a non-public, final field isn't also static, it implies that different instances can have <br /> different values. However, initializing a non-static final field in its declaration forces every instance to have the same value. So such <br /> fields should either be made static or initialized in the constructor. <br /> Noncompliant Code Example <br />  <br /> public class Myclass { <br />   public final int THRESHOLD = 3; <br /> } <br />  <br /> Compliant Solution <br />  <br /> public class Myclass { <br />   public static final int THRESHOLD = 3;    // Compliant <br /> } <br />  <br /> Exceptions <br /> No issues are reported on final fields of inner classes whose type is not a primitive or a String. Indeed according to the Java specification: <br />  <br />   An inner class is a nested class that is not explicitly or implicitly declared static. Inner classes may not declare static initializers (§8.7) <br />   or member interfaces. Inner classes may not declare static members, unless they are compile-time constant fields (§15.28). <br /> |CODE_SMELL|MINOR|1
Unnecessary imports should be removed|The imports part of a file should be handled by the Integrated Development Environment (IDE), not manually by the developer.  <br /> Unused and useless imports should not occur if that is the case.  <br /> Leaving them in reduces the code's readability, since their presence can be confusing. <br /> Noncompliant Code Example <br />  <br /> package my.company; <br />  <br /> import java.lang.String;        // Noncompliant; java.lang classes are always implicitly imported <br /> import my.company.SomeClass;    // Noncompliant; same-package files are always implicitly imported <br /> import java.io.File;            // Noncompliant; File is not used <br />  <br /> import my.company2.SomeType; <br /> import my.company2.SomeType;    // Noncompliant; 'SomeType' is already imported <br />  <br /> class ExampleClass { <br />  <br />   public String someString; <br />   public SomeType something; <br />  <br /> } <br />  <br /> Exceptions <br /> Imports for types mentioned in comments, such as Javadocs, are ignored.|CODE_SMELL|MINOR|1
